package com.fantasywalls.app.ui

import android.app.WallpaperManager
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import com.fantasywalls.app.data.MediaType
import com.fantasywalls.app.data.WallItem
import com.fantasywalls.app.wallpaper.WallpaperHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun DetailScreen(vm: MainViewModel, item: WallItem) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val gridState = rememberLazyGridState()

    fun perform(block: suspend () -> String) {
        if (busy) return
        busy = true
        scope.launch {
            val msg = try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                "ما كدرت أكمل: ${e.localizedMessage ?: "خطأ غير معروف"}"
            }
            busy = false
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {}, // يمنع اللمس من النفاذ للصفحة اللي تحت
        color = MaterialTheme.colorScheme.background
    ) {
        WallGrid(
            items = vm.similar,
            loading = vm.similarLoading,
            error = vm.similarError,
            onItemClick = vm::open,
            onLoadMore = vm::loadMoreSimilar,
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            header = {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth()) {
                        TextButton(onClick = { vm.back() }) { Text("رجوع") }
                    }

                    AsyncImage(
                        model = item.fullUrl,
                        placeholder = rememberAsyncImagePainter(item.thumbUrl),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 520.dp)
                            .clip(RoundedCornerShape(20.dp))
                    )

                    if (busy) {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                        )
                    }

                    if (item.type == MediaType.STATIC) {
                        Text(
                            text = "تعيين كخلفية",
                            style = MaterialTheme.typography.titleSmall,
                            modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                enabled = !busy,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    perform {
                                        WallpaperHelper.setStatic(ctx, item, WallpaperManager.FLAG_SYSTEM)
                                        "تم التعيين للشاشة الرئيسية ✅"
                                    }
                                }
                            ) { Text("الرئيسية") }
                            Button(
                                enabled = !busy,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    perform {
                                        WallpaperHelper.setStatic(ctx, item, WallpaperManager.FLAG_LOCK)
                                        "تم التعيين لشاشة القفل ✅"
                                    }
                                }
                            ) { Text("القفل") }
                            Button(
                                enabled = !busy,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    perform {
                                        WallpaperHelper.setStatic(
                                            ctx, item,
                                            WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                                        )
                                        "تم التعيين للاثنين ✅"
                                    }
                                }
                            ) { Text("الاثنين") }
                        }
                    } else {
                        Button(
                            enabled = !busy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            onClick = {
                                perform {
                                    WallpaperHelper.prepareLive(ctx, item)
                                    WallpaperHelper.launchLivePicker(ctx)
                                    "اضغط «تعيين الخلفية» بالشاشة اللي ظهرتلك"
                                }
                            }
                        ) { Text("تعيين كخلفية متحركة") }
                    }

                    OutlinedButton(
                        enabled = !busy,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        onClick = {
                            perform {
                                WallpaperHelper.saveToGallery(ctx, item)
                                "انحفظت بالمعرض (مجلد Pictures/FantasyWalls) ✅"
                            }
                        }
                    ) { Text("حفظ بالمعرض") }

                    Text(
                        text = "صور مشابهة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 20.dp)
                    )
                }
            }
        )
    }
}
