package com.fantasywalls.app.data

/**
 * المواقع تفهم الإنجليزي أحسن، فهذا يحوّل كلمات البحث العربية الشائعة لإنجليزي.
 * أي كلمة مو موجودة بالقاموس تنرسل مثل ما هي (يعني الإنجليزي يمشي طبيعي).
 */
object QueryTranslator {

    private fun norm(s: String): String =
        s.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ى', 'ي').replace('ة', 'ه')
            .lowercase()

    private val dict: Map<String, String> = mapOf(
        "سيارة" to "car", "سيارات" to "car", "سياره" to "car", "عربانة" to "car",
        "سلاح" to "weapon", "اسلحة" to "weapon", "أسلحة" to "weapon",
        "شيطان" to "demon", "شياطين" to "demon", "عفريت" to "demon", "جني" to "demon",
        "بنت" to "girl", "بنات" to "girl", "فتاة" to "girl", "فتيات" to "girl", "حلوة" to "beautiful",
        "فضاء" to "space", "كون" to "space", "مجرة" to "galaxy", "كوكب" to "planet", "فضائي" to "alien",
        "خيال" to "fantasy", "خيالي" to "fantasy", "خيالية" to "fantasy",
        "مقاتل" to "warrior", "محارب" to "warrior", "قتال" to "battle", "قتالي" to "battle", "معركة" to "battle",
        "وحيد" to "lone", "وحدة" to "lone",
        "مرعب" to "horror", "رعب" to "horror", "مرعبة" to "horror", "مخيف" to "horror",
        "شرير" to "villain", "اشرار" to "villain", "أشرار" to "villain", "شريرة" to "villain",
        "تنين" to "dragon", "سيف" to "sword", "فلوس" to "money", "مال" to "money", "ذهب" to "gold",
        "انمي" to "anime", "أنمي" to "anime", "طبيعة" to "nature", "قمر" to "moon", "نار" to "fire",
        "ثلج" to "ice", "غابة" to "forest", "روبوت" to "robot", "ملاك" to "angel", "هيكل" to "skeleton",
        "غراب" to "raven", "ذئب" to "wolf", "مدينة" to "city", "ليل" to "night", "سايبر" to "cyberpunk",
        "ساموراي" to "samurai", "نينجا" to "ninja", "فارس" to "knight", "ساحر" to "wizard", "ساحرة" to "witch",
        "ظلام" to "dark", "دم" to "blood", "زومبي" to "zombie", "وحش" to "monster", "وحوش" to "monster",
        "دراجة" to "motorcycle", "موتر" to "motorcycle", "طائرة" to "aircraft", "بحر" to "ocean",
        "جبل" to "mountain", "صحراء" to "desert", "برق" to "lightning", "عيون" to "eyes",
    ).mapKeys { norm(it.key) }

    fun translate(q: String): String {
        val words = q.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        return words.joinToString(" ") { w ->
            val n = norm(w)
            val bare = if (n.length > 3 && n.startsWith("ال")) n.substring(2) else n
            dict[n] ?: dict[bare] ?: w
        }
    }
}
