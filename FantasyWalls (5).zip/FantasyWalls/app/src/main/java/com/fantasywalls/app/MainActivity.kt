package com.fantasywalls.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.key
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fantasywalls.app.ui.DetailScreen
import com.fantasywalls.app.ui.FantasyTheme
import com.fantasywalls.app.ui.HomeScreen
import com.fantasywalls.app.ui.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FantasyTheme {
                // الواجهة عربية، فنثبتها من اليمين لليسار
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val vm: MainViewModel = viewModel()

                    BackHandler(enabled = vm.stack.isNotEmpty()) { vm.back() }

                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            // الصفحة الرئيسية تبقى موجودة تحت التفاصيل حتى ما يضيع مكان السكرول
                            HomeScreen(vm)

                            val current = vm.stack.lastOrNull()
                            if (current != null) {
                                key(current.id) { DetailScreen(vm, current) }
                            }
                        }
                    }
                }
            }
        }
    }
}
