package com.fantasywalls.app.data

import com.fantasywalls.app.BuildConfig
import okhttp3.HttpUrl.Companion.toHttpUrl

/**
 * الصور المتحركة (GIF) من Giphy. تحتاج مفتاح API مجاني (GIPHY_API_KEY في local.properties).
 * rating=pg-13 لتجنب المحتوى غير المناسب.
 */
object GiphyApi {
    class MissingKey : Exception("GIPHY_API_KEY is missing")

    private const val SEARCH = "https://api.giphy.com/v1/gifs/search"
    private const val LIMIT = 50
    private const val MAX_BYTES = 15L * 1024 * 1024 // فوق 15MB نستخدم نسخة أخف

    suspend fun search(query: String, page: Int, portraitOnly: Boolean): PageResult {
        val q = QueryTranslator.translate(query).ifBlank { "fantasy" }
        return fetch(q, page, portraitOnly, excludeId = null)
    }

    /** Giphy ما عنده "مشابه" رسمي، فنبحث بعنوان الصورة المنظّف */
    suspend fun similar(item: WallItem, page: Int, portraitOnly: Boolean): PageResult {
        val q = cleanTitle(item.title).ifBlank { "fantasy" }
        return fetch(q, page, portraitOnly, excludeId = item.id)
    }

    private fun cleanTitle(title: String): String =
        title.substringBefore(" GIF")
            .replace(Regex("[^\\p{L}\\p{N} ]"), " ")
            .split(" ")
            .filter { it.isNotBlank() }
            .take(4)
            .joinToString(" ")

    private suspend fun fetch(q: String, page: Int, portraitOnly: Boolean, excludeId: String?): PageResult {
        val key = BuildConfig.GIPHY_API_KEY
        if (key.isBlank()) throw MissingKey()

        val url = SEARCH.toHttpUrl().newBuilder()
            .addQueryParameter("api_key", key)
            .addQueryParameter("q", q)
            .addQueryParameter("limit", LIMIT.toString())
            .addQueryParameter("offset", ((page - 1) * LIMIT).toString())
            .addQueryParameter("rating", "pg-13")
            .build()

        val data = Http.getJson(url).optJSONArray("data") ?: return PageResult(emptyList(), false)

        val items = ArrayList<WallItem>()
        for (i in 0 until data.length()) {
            val o = data.getJSONObject(i)
            val id = o.optString("id")
            if (id.isBlank() || id == excludeId) continue
            val images = o.optJSONObject("images") ?: continue
            val orig = images.optJSONObject("original") ?: continue

            val w = orig.optString("width").toIntOrNull() ?: 0
            val h = orig.optString("height").toIntOrNull() ?: 0
            if (portraitOnly && h <= w) continue

            val size = orig.optString("size").toLongOrNull() ?: 0L
            val full = if (size > MAX_BYTES) {
                images.optJSONObject("downsized_large")?.optString("url").orEmpty()
            } else {
                orig.optString("url")
            }
            if (full.isBlank()) continue

            val thumb = images.optJSONObject("fixed_width")?.optString("url").orEmpty().ifBlank { full }

            items += WallItem(
                id = id,
                thumbUrl = thumb,
                fullUrl = full,
                type = MediaType.ANIMATED,
                title = o.optString("title"),
            )
        }
        return PageResult(items, hasMore = data.length() >= LIMIT)
    }
}
