package com.fantasywalls.app.data

import com.fantasywalls.app.BuildConfig
import okhttp3.HttpUrl.Companion.toHttpUrl

/**
 * الصور الثابتة من Wallhaven (API رسمي ومجاني).
 * purity=100 يعني محتوى آمن فقط (SFW) دائماً.
 */
object WallhavenApi {
    private const val BASE = "https://wallhaven.cc/api/v1/search"

    suspend fun search(query: String, page: Int, portraitOnly: Boolean): PageResult =
        fetch(QueryTranslator.translate(query), page, portraitOnly)

    /** Wallhaven يدعم like:ID لجلب صور بتاغات مشابهة */
    suspend fun similar(id: String, page: Int, portraitOnly: Boolean): PageResult =
        fetch("like:$id", page, portraitOnly)

    private suspend fun fetch(q: String, page: Int, portraitOnly: Boolean): PageResult {
        val url = BASE.toHttpUrl().newBuilder()
            .addQueryParameter("categories", "111")
            .addQueryParameter("purity", "100")
            .addQueryParameter("sorting", if (q.isBlank()) "toplist" else "relevance")
            .addQueryParameter("page", page.toString())
        if (q.isNotBlank()) url.addQueryParameter("q", q)
        if (portraitOnly) url.addQueryParameter("ratios", "portrait")
        if (BuildConfig.WALLHAVEN_API_KEY.isNotBlank()) {
            url.addQueryParameter("apikey", BuildConfig.WALLHAVEN_API_KEY)
        }

        val json = Http.getJson(url.build())
        val arr = json.optJSONArray("data") ?: return PageResult(emptyList(), false)

        val items = ArrayList<WallItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val thumbs = o.optJSONObject("thumbs") ?: continue
            items += WallItem(
                id = o.getString("id"),
                thumbUrl = thumbs.optString("large").ifBlank { thumbs.optString("small") },
                fullUrl = o.getString("path"),
                type = MediaType.STATIC,
            )
        }

        val meta = json.optJSONObject("meta")
        val current = meta?.optInt("current_page", page) ?: page
        val last = meta?.optInt("last_page", page) ?: page
        return PageResult(items, current < last)
    }
}
