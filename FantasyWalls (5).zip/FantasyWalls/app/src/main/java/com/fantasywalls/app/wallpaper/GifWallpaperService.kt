package com.fantasywalls.app.wallpaper

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.ceil
import kotlin.math.max

/**
 * خلفية متحركة تعرض الـ GIF اللي نزّله التطبيق (filesDir/live_wallpaper.gif)
 * بحجم يغطي الشاشة (center-crop). تتوقف الحركة عند إطفاء الشاشة لتوفير البطارية.
 */
class GifWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = GifEngine()

    private inner class GifEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val prefs: SharedPreferences =
            getSharedPreferences(WallpaperStore.PREFS, Context.MODE_PRIVATE)

        // لازم نحتفظ بمرجع قوي، لأن SharedPreferences تمسك المستمع بشكل ضعيف
        private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == WallpaperStore.KEY_VERSION) loadGif()
        }

        private var drawable: Drawable? = null
        private var visible = false
        private var width = 0
        private var height = 0

        private val drawableCallback = object : Drawable.Callback {
            override fun invalidateDrawable(who: Drawable) {
                drawFrame()
            }

            override fun scheduleDrawable(who: Drawable, what: Runnable, `when`: Long) {
                handler.postAtTime(what, who, `when`)
            }

            override fun unscheduleDrawable(who: Drawable, what: Runnable) {
                handler.removeCallbacks(what, who)
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(prefsListener)
            loadGif()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            super.onSurfaceChanged(holder, format, w, h)
            width = w
            height = h
            fitBounds()
            drawFrame()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            val d = drawable
            if (d is AnimatedImageDrawable) {
                if (isVisible) d.start() else d.stop()
            }
            if (isVisible) drawFrame()
        }

        override fun onDestroy() {
            super.onDestroy()
            prefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
            handler.removeCallbacksAndMessages(null)
            releaseDrawable()
        }

        private fun releaseDrawable() {
            val d = drawable
            if (d is AnimatedImageDrawable) d.stop()
            d?.callback = null
            drawable = null
        }

        private fun loadGif() {
            releaseDrawable()
            val file = File(filesDir, WallpaperStore.GIF_FILE)
            if (file.exists()) {
                try {
                    val source = ImageDecoder.createSource(file)
                    val d = ImageDecoder.decodeDrawable(source) { decoder, info, _ ->
                        // نصغّر الـ GIF الضخم حتى ما ينفد الرام
                        val biggest = max(info.size.width, info.size.height)
                        if (biggest > MAX_DECODE_SIDE) {
                            decoder.setTargetSampleSize(ceil(biggest / MAX_DECODE_SIDE.toFloat()).toInt())
                        }
                    }
                    d.callback = drawableCallback
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        if (visible) d.start()
                    }
                    drawable = d
                } catch (e: Exception) {
                    drawable = null
                }
            }
            fitBounds()
            drawFrame()
        }

        /** تكبير الصورة لتغطي الشاشة كلها مع قص الزوائد من الوسط */
        private fun fitBounds() {
            val d = drawable ?: return
            if (width == 0 || height == 0) return
            val iw = d.intrinsicWidth.coerceAtLeast(1)
            val ih = d.intrinsicHeight.coerceAtLeast(1)
            val scale = max(width / iw.toFloat(), height / ih.toFloat())
            val dw = (iw * scale).toInt()
            val dh = (ih * scale).toInt()
            val left = (width - dw) / 2
            val top = (height - dh) / 2
            d.setBounds(left, top, left + dw, top + dh)
        }

        private fun drawFrame() {
            val holder = surfaceHolder ?: return
            if (!holder.surface.isValid) return
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    canvas.drawColor(Color.BLACK)
                    drawable?.draw(canvas)
                }
            } catch (e: Exception) {
                // السطح ممكن ينغلق أثناء الرسم، نتجاهل
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Exception) {
                        // نتجاهل
                    }
                }
            }
        }
    }

    private companion object {
        const val MAX_DECODE_SIDE = 1920
    }
}
