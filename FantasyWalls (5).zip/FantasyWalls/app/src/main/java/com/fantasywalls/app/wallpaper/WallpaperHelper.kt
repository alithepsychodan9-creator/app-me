package com.fantasywalls.app.wallpaper

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Environment
import android.provider.MediaStore
import com.fantasywalls.app.data.Http
import com.fantasywalls.app.data.MediaType
import com.fantasywalls.app.data.WallItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.IOException

object WallpaperHelper {

    /** تنزيل الصورة الكاملة وتعيينها كخلفية ثابتة. which = FLAG_SYSTEM / FLAG_LOCK / الاثنين. */
    suspend fun setStatic(ctx: Context, item: WallItem, which: Int) = withContext(Dispatchers.IO) {
        val file = File(ctx.cacheDir, "wall_${item.id}.${extOf(item)}")
        download(item.fullUrl, file)
        val wm = WallpaperManager.getInstance(ctx)
        FileInputStream(file).use { input ->
            wm.setStream(input, null, true, which)
        }
    }

    /** ينزّل الـ GIF ويحفظه بمكان تقرأه منه خدمة الخلفية المتحركة، ويبلّغها تتحدث. */
    suspend fun prepareLive(ctx: Context, item: WallItem) = withContext(Dispatchers.IO) {
        download(item.fullUrl, File(ctx.filesDir, WallpaperStore.GIF_FILE))
        ctx.getSharedPreferences(WallpaperStore.PREFS, Context.MODE_PRIVATE)
            .edit()
            .putLong(WallpaperStore.KEY_VERSION, System.currentTimeMillis())
            .apply()
    }

    /** يفتح شاشة معاينة الخلفية المتحركة (وفيها زر التعيين). */
    fun launchLivePicker(ctx: Context) {
        val component = ComponentName(ctx, GifWallpaperService::class.java)
        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
        try {
            ctx.startActivity(direct)
        } catch (e: Exception) {
            // بعض الأجهزة ما تدعم الطريقة المباشرة، فنفتح قائمة الخلفيات المتحركة
            ctx.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    /** يحفظ الصورة (أو الـ GIF) بمعرض الجهاز داخل Pictures/FantasyWalls. */
    suspend fun saveToGallery(ctx: Context, item: WallItem) = withContext(Dispatchers.IO) {
        val ext = extOf(item)
        val file = File(ctx.cacheDir, "save_${item.id}.$ext")
        download(item.fullUrl, file)

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "fantasy_${item.id}.$ext")
            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(ext))
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/FantasyWalls")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("ما كدرت أنشئ الملف بالمعرض")

        val out = resolver.openOutputStream(uri) ?: throw IOException("ما كدرت أكتب الملف")
        out.use { o -> file.inputStream().use { it.copyTo(o) } }

        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    }

    // ---------- أدوات داخلية ----------

    private fun download(url: String, dest: File) {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "FantasyWalls/1.0")
            .build()
        Http.client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("فشل التنزيل (HTTP ${resp.code})")
            val body = resp.body ?: throw IOException("الرد فاضي")
            dest.parentFile?.mkdirs()
            val tmp = File(dest.path + ".part")
            body.byteStream().use { input ->
                tmp.outputStream().use { input.copyTo(it) }
            }
            if (!tmp.renameTo(dest)) {
                tmp.copyTo(dest, overwrite = true)
                tmp.delete()
            }
        }
    }

    private fun extOf(item: WallItem): String {
        if (item.type == MediaType.ANIMATED) return "gif"
        val e = item.fullUrl.substringBefore('?').substringAfterLast('.', "jpg").lowercase()
        return if (e in setOf("jpg", "jpeg", "png", "webp")) e else "jpg"
    }

    private fun mimeOf(ext: String): String = when (ext) {
        "png" -> "image/png"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        else -> "image/jpeg"
    }
}
