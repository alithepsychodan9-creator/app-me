package com.fantasywalls.app.wallpaper

/** ثوابت مشتركة بين التطبيق وخدمة الخلفية المتحركة. */
object WallpaperStore {
    const val PREFS = "live_wallpaper"
    const val KEY_VERSION = "version"
    const val GIF_FILE = "live_wallpaper.gif"
}
