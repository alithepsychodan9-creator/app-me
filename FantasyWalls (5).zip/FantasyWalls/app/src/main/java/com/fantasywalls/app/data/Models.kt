package com.fantasywalls.app.data

enum class MediaType { STATIC, ANIMATED }

data class WallItem(
    val id: String,
    val thumbUrl: String,
    val fullUrl: String,
    val type: MediaType,
    val title: String = "",
)

data class PageResult(val items: List<WallItem>, val hasMore: Boolean)

/** label = اللي يظهر للمستخدم، query = كلمات البحث (إنجليزي لأن المواقع تفهمه أحسن) */
data class Category(val label: String, val query: String)

val Categories = listOf(
    Category("⚔️ خيال قتالي", "fantasy battle warrior"),
    Category("💀 شخصيات مرعبة", "horror creature"),
    Category("😈 أشرار", "villain dark evil"),
    Category("🗡️ مقاتل وحيد", "lone warrior"),
    Category("🌈 ألوان خيالية", "fantasy colorful art"),
    Category("🚗 سيارات", "sports car"),
    Category("🔫 أسلحة", "fantasy weapon"),
    Category("👹 شياطين", "demon"),
    Category("👩 بنات", "fantasy girl"),
    Category("🪐 فضاء وعوالم", "space alien world"),
    Category("💰 فلوس وفخامة", "money luxury"),
)
