package com.fantasywalls.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFFB57CFF),
    onPrimary = Color(0xFF1B0B33),
    secondary = Color(0xFF38E8FF),
    onSecondary = Color(0xFF00363D),
    background = Color(0xFF0E0B16),
    onBackground = Color(0xFFEDE7F6),
    surface = Color(0xFF181328),
    onSurface = Color(0xFFEDE7F6),
    surfaceVariant = Color(0xFF241C3B),
    onSurfaceVariant = Color(0xFFC9BEE0),
    error = Color(0xFFFF6B8A),
)

@Composable
fun FantasyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
