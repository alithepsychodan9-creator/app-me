package com.fantasywalls.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.fantasywalls.app.data.Categories
import com.fantasywalls.app.data.GiphyApi
import com.fantasywalls.app.data.MediaType
import com.fantasywalls.app.data.PageResult
import com.fantasywalls.app.data.WallItem
import com.fantasywalls.app.data.WallhavenApi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.IOException

/** يجلب صفحات متتالية، وإذا الصفحة طلعت فاضية بعد الفلترة يجرّب اللي بعدها (حد أقصى 3). */
private class Feed(val fetch: suspend (page: Int) -> PageResult) {
    var page = 1
    var hasMore = true

    suspend fun next(): List<WallItem> {
        var tries = 0
        while (hasMore && tries < 3) {
            val r = fetch(page)
            page++
            tries++
            hasMore = r.hasMore
            if (r.items.isNotEmpty()) return r.items
        }
        return emptyList()
    }
}

class MainViewModel : ViewModel() {

    // ---- القائمة الرئيسية ----
    var mode by mutableStateOf(MediaType.STATIC); private set
    var query by mutableStateOf(Categories.first().query); private set
    var portraitOnly by mutableStateOf(true); private set
    var items by mutableStateOf<List<WallItem>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    // ---- شاشة التفاصيل (ستاك حتى تكدر تنتقل من صورة لمشابهتها وترجع) ----
    val stack = mutableStateListOf<WallItem>()
    var similar by mutableStateOf<List<WallItem>>(emptyList()); private set
    var similarLoading by mutableStateOf(false); private set
    var similarError by mutableStateOf<String?>(null); private set

    private var feed: Feed? = null
    private var feedJob: Job? = null
    private var similarFeed: Feed? = null
    private var similarJob: Job? = null

    init {
        reload()
    }

    fun search(q: String) {
        query = q
        reload()
    }

    fun setMode(m: MediaType) {
        if (m == mode) return
        mode = m
        reload()
    }

    fun setPortrait(v: Boolean) {
        if (v == portraitOnly) return
        portraitOnly = v
        reload()
    }

    private fun reload() {
        feedJob?.cancel()
        items = emptyList()
        error = null
        loading = false
        val q = query
        val m = mode
        val p = portraitOnly
        feed = Feed { page ->
            if (m == MediaType.STATIC) WallhavenApi.search(q, page, p)
            else GiphyApi.search(q, page, p)
        }
        loadMore()
    }

    fun loadMore() {
        val f = feed ?: return
        if (loading || !f.hasMore) return
        loading = true
        error = null
        feedJob = viewModelScope.launch {
            try {
                val new = f.next()
                if (feed === f) items = (items + new).distinctBy { it.id }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (feed === f) error = friendly(e)
            } finally {
                if (feed === f) loading = false
            }
        }
    }

    // ---- التفاصيل والمشابه ----

    fun open(item: WallItem) {
        stack.add(item)
        loadSimilar(item)
    }

    fun back(): Boolean {
        if (stack.isEmpty()) return false
        stack.removeAt(stack.lastIndex)
        val cur = stack.lastOrNull()
        if (cur != null) {
            loadSimilar(cur)
        } else {
            similarJob?.cancel()
            similarFeed = null
            similar = emptyList()
            similarLoading = false
            similarError = null
        }
        return true
    }

    private fun loadSimilar(item: WallItem) {
        similarJob?.cancel()
        similar = emptyList()
        similarError = null
        similarLoading = false
        val p = portraitOnly
        similarFeed = Feed { page ->
            if (item.type == MediaType.STATIC) WallhavenApi.similar(item.id, page, p)
            else GiphyApi.similar(item, page, p)
        }
        loadMoreSimilar()
    }

    fun loadMoreSimilar() {
        val f = similarFeed ?: return
        if (similarLoading || !f.hasMore) return
        val currentId = stack.lastOrNull()?.id
        similarLoading = true
        similarError = null
        similarJob = viewModelScope.launch {
            try {
                val new = f.next().filter { it.id != currentId }
                if (similarFeed === f) similar = (similar + new).distinctBy { it.id }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (similarFeed === f) similarError = friendly(e)
            } finally {
                if (similarFeed === f) similarLoading = false
            }
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is GiphyApi.MissingKey ->
            "الصور المتحركة تحتاج مفتاح Giphy مجاني. حطه بملف local.properties (مكتوب بالشرح) وأعد بناء التطبيق."
        is IOException ->
            "مشكلة بالاتصال أو الموقع ما يستجيب. تأكد من الإنترنت وحاول مرة ثانية."
        else -> "صار خطأ غير متوقع."
    }
}
