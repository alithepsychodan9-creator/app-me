package com.fantasywalls.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.fantasywalls.app.data.Categories
import com.fantasywalls.app.data.MediaType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel) {
    var text by rememberSaveable { mutableStateOf("") }
    val focus = LocalFocusManager.current
    val gridState = rememberLazyGridState()

    // كل ما يتغير البحث أو النوع نرجع لأول الشبكة
    LaunchedEffect(vm.query, vm.mode, vm.portraitOnly) {
        gridState.scrollToItem(0)
    }

    fun submit() {
        val q = text.trim()
        if (q.isNotEmpty()) {
            vm.search(q)
            focus.clearFocus()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "خلفيات خيالية",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp)
        )

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            placeholder = { Text("دوّر: تنين، سيارات، فضاء، demon...") },
            trailingIcon = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (text.isNotEmpty()) {
                        IconButton(onClick = { text = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح")
                        }
                    }
                    IconButton(onClick = { submit() }) {
                        Icon(Icons.Default.Search, contentDescription = "بحث")
                    }
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { submit() }),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = vm.mode == MediaType.STATIC,
                onClick = { vm.setMode(MediaType.STATIC) },
                label = { Text("🖼️ ثابتة") }
            )
            FilterChip(
                selected = vm.mode == MediaType.ANIMATED,
                onClick = { vm.setMode(MediaType.ANIMATED) },
                label = { Text("🎞️ متحركة") }
            )
            FilterChip(
                selected = vm.portraitOnly,
                onClick = { vm.setPortrait(!vm.portraitOnly) },
                label = { Text("📱 عمودي") }
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(Categories) { c ->
                FilterChip(
                    selected = vm.query == c.query,
                    onClick = {
                        text = ""
                        focus.clearFocus()
                        vm.search(c.query)
                    },
                    label = { Text(c.label) }
                )
            }
        }

        WallGrid(
            items = vm.items,
            loading = vm.loading,
            error = vm.error,
            onItemClick = vm::open,
            onLoadMore = vm::loadMore,
            state = gridState,
            modifier = Modifier.fillMaxSize()
        )
    }
}
